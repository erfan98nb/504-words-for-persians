//
//  TableViewCell.swift
//  504Words
//
//  Created by MAC os on 1/31/21.
//

import UIKit

class MyTableViewCell: UITableViewCell {

    @IBOutlet weak var blueview: UIView!
    @IBOutlet weak var myimage: UIImageView!
    @IBOutlet weak var label: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        let color1: UIColor = .random

       }
 

}
